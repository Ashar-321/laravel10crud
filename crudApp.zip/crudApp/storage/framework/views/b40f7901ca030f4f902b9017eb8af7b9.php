<!DOCTYPE html>
<html>
<head>
    <title>Laravel 10 CRUD with Image Upload Tutorial: A Step-by-Step Guide</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
   
</body>
</html><?php /**PATH D:\Laravel\crudApp\resources\views/layout.blade.php ENDPATH**/ ?>