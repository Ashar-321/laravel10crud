<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
// Route::resource('products', [ProductController::class]);
Route::get('products', [ProductController::class, 'index']);
Route::get('products/create', [ProductController::class, 'create'])->name('create');

Route::get('products', [ProductController::class, 'index'])->name('index');
Route::post('products', [ProductController::class, 'store'])->name('store');
Route::delete('products/{product}', [ProductController::class, 'destroy'])->name('destroy');
Route::get('products/{product}', [ProductController::class, 'show'])->name('show');
Route::get('products/{product}/edit', [ProductController::class, 'edit'])->name('edit');
Route::get('products/{product}/edit', [ProductController::class, 'update'])->name('update');
Route::get('products/{product}/edit', [ProductController::class, 'edit'])->name('edit');
Route::put('products/{product}', [ProductController::class, 'update'])->name('update');


